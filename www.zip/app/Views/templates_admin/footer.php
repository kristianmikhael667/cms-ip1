<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-6">
                2020 © Infinity One Plus.
            </div>
        </div>
    </div>
</footer>